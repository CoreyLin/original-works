import org.bouncycastle.openssl.PEMWriter;
import org.hyperledger.fabric.sdk.*;
import org.hyperledger.fabric.sdk.security.CryptoSuite;
import org.hyperledger.fabric_ca.sdk.HFCAClient;
import org.hyperledger.fabric_ca.sdk.HFCAInfo;
import org.hyperledger.fabric_ca.sdk.RegistrationRequest;

import java.io.IOException;
import java.io.StringWriter;
import java.security.PrivateKey;
import java.util.Collection;
import java.util.LinkedList;
import java.util.regex.Pattern;

public class Experiment {
    public static void main(String[] args) throws Exception {
        //register和enroll一个client identity，用于调用链码。此处172.19.102.63:7054是已经搭建好的org1的Fabric CA server
        HFCAClient ca = HFCAClient.createNewInstance("http://172.19.102.63:7054",
                null); //不能传caName进去，就传null即可，如果传一个caName，就会报错
        ca.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());
        //检查一下是否能成功连接到Fabric CA server
        HFCAInfo info = ca.info();
        System.out.println(info != null); //如果成功连接到Fabric CA server，那么HFCAInfo不为null
        System.out.println(info.getCAName());

        //admin是一个bootstrap identity，在Fabric CA server启动的时候就已经被register了，此处只需要enroll admin即可
        Enrollment enroll = ca.enroll("admin", "adminpw");
        SampleUser admin = new SampleUser();
        admin.setName("admin");
        admin.setMspId("Org1MSP");
        admin.setEnrollment(enroll);
//        String pemStringFromPrivateKey = getPEMStringFromPrivateKey(enroll.getKey());
//        String cert = enroll.getCert();

//        System.out.println(pemStringFromPrivateKey);
//        System.out.println("-----------------------");
//        System.out.println(cert);
//        System.out.println("-----------------------");

        //用admin注册一个新的identity
//        RegistrationRequest rr = new RegistrationRequest("user3", "org1");
//        rr.setSecret("user3pw");
//        String secret = ca.register(rr, admin);
//        System.out.println(secret);
        //enroll这个新的identity，注意：enroll的前提是这个identity已经被register
        Enrollment enroll3 = ca.enroll("user3", "user3pw");
        String pemStringFromPrivateKey1 = getPEMStringFromPrivateKey(enroll3.getKey());
        String cert1 = enroll3.getCert();
        System.out.println(pemStringFromPrivateKey1);
        System.out.println("-----------------------");
        System.out.println(cert1);
        System.out.println("-----------------------");
        //创建一个User，用于封装刚刚enroll的identity
        SampleUser user3 = new SampleUser();
        user3.setName("user3");
        user3.setMspId("Org1MSP");
        user3.setEnrollment(enroll3);

        //构造一个HFClient，与已经搭建好的Fabric网络进行交互
        HFClient client = HFClient.createNewInstance();
        client.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());
        //把刚刚生成的User设置为客户端的上下文
        client.setUserContext(user3);

        //构造一个Channel
        //new一个channel对象。注意，此处调用的是public Channel newChannel(String name)，用于返回一个已经配置好的通道，并不会创建一个新的通道
        //如想创建一个全新的通道，应该调用Channel newChannel(String name, Orderer orderer, ChannelConfiguration channelConfiguration,
        // byte[]... channelConfigurationSignatures)
        //再强调一下，Fabric网络已经手工搭建好，通道也提前创建好了，链码也安装、实例化好了。此处想验证的是用Fabric CA server生成的identity的私钥和证书能否对链码进行成功的调用
        Channel channel = client.newChannel("mychannel");
        //把这个channel相关的所有orderer都添加到channel里面。
        Orderer orderer0 = client.newOrderer("orderer0.yingzi.com", "grpc://172.19.102.62:7050");
        Orderer orderer1 = client.newOrderer("orderer1.yingzi.com", "grpc://172.19.102.63:7050");
        Orderer orderer2 = client.newOrderer("orderer2.yingzi.com", "grpc://172.19.102.64:7050");
        channel.addOrderer(orderer0);
        channel.addOrderer(orderer1);
        channel.addOrderer(orderer2);
        //把与这个channel相关的所有peer都添加到channel里面。注意：只添加安装了链码的peer。由于peer1org1,peer1org2没有安装链码，所以不添加
        Peer peer0org1 = client.newPeer("peer0.org1.yingzi.com", "grpc://172.19.102.62:7051");
        Peer peer0org2 = client.newPeer("peer0.org2.yingzi.com", "grpc://172.19.102.63:7051");
        channel.addPeer(peer0org1);
        channel.addPeer(peer0org2);

        //初始化channel，这一步非常重要，如果缺失，就会报错
        channel.initialize();

        //注册一个链码事件监听器，适用于所有chaincode id
        String chaincodeEventListenerHandle = channel.registerChaincodeEventListener(Pattern.compile(".*"),
                Pattern.compile(Pattern.quote("event")),
                (handle, blockEvent, chaincodeEvent) -> {
                    String es = blockEvent.getPeer() != null ? blockEvent.getPeer().getName() : "peer was null!!!";
                    System.out.printf("RECEIVED Chaincode event with handle: %s, chaincode Id: %s, chaincode event " +
                                    "name: %s, "
                                    + "transaction id: %s, event payload: \"%s\", from event source: %s\n",
                            handle, chaincodeEvent.getChaincodeId(),
                            chaincodeEvent.getEventName(),
                            chaincodeEvent.getTxId(),
                            new String(chaincodeEvent.getPayload()), es);
                });

        //构造ChaincodeID。此处的mycc 1.0是已经安装并且实例化的链码
        ChaincodeID.Builder chaincodeIDBuilder = ChaincodeID.newBuilder().setName("mycc")
                .setVersion("1.0");
        ChaincodeID chaincodeID = chaincodeIDBuilder.build();

        //构造TransactionProposalRequest
        TransactionProposalRequest transactionProposalRequest = client.newTransactionProposalRequest();
        transactionProposalRequest.setChaincodeID(chaincodeID);
        transactionProposalRequest.setChaincodeLanguage(TransactionRequest.Type.GO_LANG);
        transactionProposalRequest.setFcn("invoke");
        transactionProposalRequest.setProposalWaitTime(120000);
        transactionProposalRequest.setArgs("a", "b", "10");

        //把transaction proposal发送给channel中的peer，注：peer上必须安装了链码，没有安装链码的peer不用发送
        Collection<ProposalResponse> successful = new LinkedList<>();
        Collection<ProposalResponse> transactionPropResp = channel.sendTransactionProposal(transactionProposalRequest
                , channel.getPeers());
        for (ProposalResponse response : transactionPropResp) {
            if (response.getStatus() == ProposalResponse.Status.SUCCESS) {
                System.out.printf("Successful transaction proposal response Txid: %s from peer %s\n",
                        response.getTransactionID(), response.getPeer().getName());
                successful.add(response);
            } else {
                System.out.println("message:" + response.getMessage());
                System.out.println("status:" + response.getStatus());
                System.out.println("peername" + response.getPeer().getName());
                System.out.println("url" + response.getPeer().getUrl());
                System.out.println("chaincodeid" + response.getChaincodeID().getName());
                System.out.println("---------------------------------------------------");
            }
        }

        //把ProposalResponse，也就是peer返回的签名读写集发送给orderer进行排序，写入一个新的区块，写入账本，即couchdb
        channel.sendTransaction(successful).thenApply(transactionEvent -> {
            System.out.println("isvalid:" + transactionEvent.isValid());
            if (transactionEvent.isValid()) {
                System.out.println("Finished transaction with transaction id:" + transactionEvent.getTransactionID());
            }
            return null;
        });
    }

    public static String getPEMStringFromPrivateKey(PrivateKey privateKey) throws IOException {
        StringWriter pemStrWriter = new StringWriter();
        PEMWriter pemWriter = new PEMWriter(pemStrWriter);

        pemWriter.writeObject(privateKey);

        pemWriter.close();

        return pemStrWriter.toString();
    }
}
